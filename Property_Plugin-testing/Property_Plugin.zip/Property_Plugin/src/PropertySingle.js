import React, { useState } from 'react';
import './PropertySingle.css';

function PropertySingle({ property, onBack }) {
  const [activeTab, setActiveTab] = useState('overview');
  const [mainImage, setMainImage] = useState(0);
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    message: 'I\'m interested in this property...'
  });

  // Mock gallery images (replace with actual property gallery)
  const galleryImages = [
    property?.thumbnail || 'https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?w=800',
    'https://images.unsplash.com/photo-1600585154340-be6161a56a0c?w=800',
    'https://images.unsplash.com/photo-1600607687939-ce8a6c25118c?w=800',
    'https://images.unsplash.com/photo-1600566753190-17f0baa2a6c3?w=800',
    'https://images.unsplash.com/photo-1600573472592-401b489a3cdc?w=800',
  ];

  const handleInputChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    console.log('Form submitted:', formData);
    alert('Thank you! We will contact you soon.');
  };

  if (!property) {
    return <div className="property-plugin-loading">Loading property details...</div>;
  }

  return (
    <div className="property-single-page">
      {/* Breadcrumb */}
      <div className="property-breadcrumb">
        <div className="property-plugin-container">
          <span onClick={onBack} className="breadcrumb-link">Home</span>
          <span className="breadcrumb-separator">›</span>
          <span onClick={onBack} className="breadcrumb-link">Properties</span>
          <span className="breadcrumb-separator">›</span>
          <span className="breadcrumb-current">{property.title}</span>
        </div>
      </div>

      {/* Main Content Layout */}
      <div className="property-plugin-container">
        <div className="property-single-layout">
          
          {/* Left Column - Gallery & Details */}
          <div className="property-single-main">
            
            {/* Image Gallery */}
            <div className="property-gallery">
              <div className="gallery-main">
                <img 
                  src={galleryImages[mainImage]} 
                  alt={property.title}
                  className="gallery-main-image"
                />
                <div className="gallery-badge">For Sale</div>
                <div className="gallery-actions">
                  <button className="gallery-action-btn">♡</button>
                  <button className="gallery-action-btn">↗</button>
                </div>
                <div className="gallery-counter">{mainImage + 1} / {galleryImages.length}</div>
              </div>
              <div className="gallery-thumbnails">
                <button 
                  className="gallery-nav gallery-nav-prev"
                  onClick={() => setMainImage(Math.max(0, mainImage - 1))}
                >
                  ‹
                </button>
                {galleryImages.map((img, index) => (
                  <div 
                    key={index}
                    className={`gallery-thumb ${index === mainImage ? 'active' : ''}`}
                    onClick={() => setMainImage(index)}
                  >
                    <img src={img} alt={`View ${index + 1}`} />
                  </div>
                ))}
                <button 
                  className="gallery-nav gallery-nav-next"
                  onClick={() => setMainImage(Math.min(galleryImages.length - 1, mainImage + 1))}
                >
                  ›
                </button>
              </div>
            </div>

            {/* Tabs Navigation */}
            <div className="property-tabs">
              {['Overview', 'Features', 'Amenities', 'Floor Plans', 'Location', 'Video', 'Nearby Places'].map((tab) => (
                <button
                  key={tab}
                  className={`property-tab ${activeTab === tab.toLowerCase() ? 'active' : ''}`}
                  onClick={() => setActiveTab(tab.toLowerCase())}
                >
                  {tab}
                </button>
              ))}
            </div>

            {/* Overview Section */}
            <div className="property-overview-section">
              <div className="overview-two-column">
                <div className="overview-description">
                  <h3>About This Property</h3>
                  <p>
                    This stunning modern villa offers the perfect blend of luxury, comfort, and contemporary design. 
                    Located in one of the most prestigious neighborhoods, this property features high-end finishes, 
                    spacious living areas, and breathtaking views.
                  </p>
                  <ul className="overview-highlights">
                    <li>✓ Spacious open-concept living and dining area</li>
                    <li>✓ Private swimming pool and landscaped garden</li>
                    <li>✓ High-end kitchen with premium appliances</li>
                    <li>✓ Smart home system and security</li>
                    <li>✓ Floor-to-ceiling windows with natural light</li>
                    <li>✓ Prime location near schools and shopping</li>
                  </ul>
                </div>
                <div className="overview-map">
                  <h3>Property Location</h3>
                  <div className="map-placeholder">
                    <div className="map-pin">📍</div>
                    <p>Map View</p>
                  </div>
                </div>
              </div>

              {/* Bottom Price Bar */}
              <div className="property-bottom-bar">
                <div className="bottom-price">
                  <span className="price-amount">{property.price}</span>
                  <span className="price-badge">For Sale</span>
                </div>
                <div className="bottom-actions">
                  <button className="btn-call">
                     +1 (555) 123-4567
                  </button>
                  <button className="btn-schedule">
                     Schedule a Tour
                  </button>
                  <button className="btn-request-info">
                    Request Information
                  </button>
                </div>
              </div>
            </div>
          </div>

          {/* Right Column - Sidebar */}
          <div className="property-single-sidebar">
            
            {/* Property Details */}
            <div className="property-details-card">
              <div className="details-header">
                <span className="featured-label">FEATURED PROPERTY</span>
                <h1 className="property-title">{property.title}</h1>
                <p className="property-address"> {property.address}</p>
                <div className="property-price-large">
                  <span className="price">{property.price}</span>
                  <span className="status-badge">For Sale</span>
                </div>
              </div>

              {/* Quick Stats */}
              <div className="property-quick-stats">
                <div className="stat-item">
                  <span className="stat-icon">🛏</span>
                  <div>
                    <span className="stat-value">{property.bedrooms || '4'}</span>
                    <span className="stat-label">Bedrooms</span>
                  </div>
                </div>
                <div className="stat-item">
                  <span className="stat-icon">🚿</span>
                  <div>
                    <span className="stat-value">{property.bathrooms || '3'}</span>
                    <span className="stat-label">Bathrooms</span>
                  </div>
                </div>
                <div className="stat-item">
                  <span className="stat-icon"></span>
                  <div>
                    <span className="stat-value">{property.area || '2,500'}</span>
                    <span className="stat-label">Sq Ft</span>
                  </div>
                </div>
                <div className="stat-item">
                  <span className="stat-icon">🚗</span>
                  <div>
                    <span className="stat-value">{property.garage || '2'}</span>
                    <span className="stat-label">Garage</span>
                  </div>
                </div>
              </div>

              {/* Detailed Information */}
              <div className="property-info-list">
                <div className="info-row">
                  <span className="info-label">Property Type:</span>
                  <span className="info-value">{property.type || 'Villa'}</span>
                </div>
                <div className="info-row">
                  <span className="info-label">Property Status:</span>
                  <span className="info-value">For Sale</span>
                </div>
                <div className="info-row">
                  <span className="info-label">Property ID:</span>
                  <span className="info-value">{property.id || 'WPS-2548'}</span>
                </div>
                <div className="info-row">
                  <span className="info-label">Year Built:</span>
                  <span className="info-value">{property.year_built || '2022'}</span>
                </div>
                <div className="info-row">
                  <span className="info-label">Lot Area:</span>
                  <span className="info-value">{property.lot_area || '0.35 Acres'}</span>
                </div>
                <div className="info-row">
                  <span className="info-label">Property Size:</span>
                  <span className="info-value">{property.area || '2,500 Sq Ft'}</span>
                </div>
                <div className="info-row">
                  <span className="info-label">Garages:</span>
                  <span className="info-value">{property.garage || '2 Cars'}</span>
                </div>
                <div className="info-row">
                  <span className="info-label">Heating:</span>
                  <span className="info-value">{property.heating || 'Central Heating'}</span>
                </div>
                <div className="info-row">
                  <span className="info-label">Cooling:</span>
                  <span className="info-value">{property.cooling || 'Central Air'}</span>
                </div>
                <div className="info-row">
                  <span className="info-label">Property Tax:</span>
                  <span className="info-value">{property.tax || '$8,432 (Annual)'}</span>
                </div>
              </div>
            </div>

            {/* Contact Form */}
            <div className="contact-form-card">
              <h3>Get More Details</h3>
              <p className="form-subtitle">Schedule a tour or request more information about this property.</p>
              <form onSubmit={handleSubmit}>
                <div className="form-group">
                  <input 
                    type="text" 
                    name="name" 
                    placeholder="Your Name*" 
                    value={formData.name}
                    onChange={handleInputChange}
                    required
                  />
                </div>
                <div className="form-group">
                  <input 
                    type="email" 
                    name="email" 
                    placeholder="Your Email*" 
                    value={formData.email}
                    onChange={handleInputChange}
                    required
                  />
                </div>
                <div className="form-group">
                  <input 
                    type="tel" 
                    name="phone" 
                    placeholder="Your Phone Number*" 
                    value={formData.phone}
                    onChange={handleInputChange}
                    required
                  />
                </div>
                <div className="form-group">
                  <textarea 
                    name="message" 
                    placeholder="I'm interested in this property..."
                    value={formData.message}
                    onChange={handleInputChange}
                    rows="4"
                  ></textarea>
                </div>
                <button type="submit" className="btn-submit-form">
                  Request Information
                </button>
                <p className="form-privacy">
                  🔒 Your information is safe with us. We don't share your details with third parties.
                </p>
              </form>
            </div>

            {/* Agent Card */}
            <div className="agent-card">
              <div className="agent-header">
                <img 
                  src="https://images.unsplash.com/photo-1560250097-0b93528c311a?w=100" 
                  alt="Agent" 
                  className="agent-photo"
                />
                <div className="agent-info">
                  <h4>John Smith</h4>
                  <p>Property Agent</p>
                </div>
                <div className="agent-contact">
                  <button className="btn-agent-phone">📞</button>
                  <button className="btn-agent-email">✉</button>
                </div>
              </div>
              <button className="btn-view-properties">View All Properties</button>
            </div>

            {/* Action Buttons */}
            <div className="property-actions">
              <button className="action-btn">
                <span className="action-icon">❤</span>
                Add to Favorites
              </button>
              <button className="action-btn">
                <span className="action-icon"></span>
                Compare Property
              </button>
              <button className="action-btn">
                <span className="action-icon"></span>
                Share Property
              </button>
              <div className="social-share">
                <a href="#" className="social-icon">f</a>
                <a href="#" className="social-icon">𝕏</a>
                <a href="#" className="social-icon">in</a>
                <a href="#" className="social-icon">📧</a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default PropertySingle;
