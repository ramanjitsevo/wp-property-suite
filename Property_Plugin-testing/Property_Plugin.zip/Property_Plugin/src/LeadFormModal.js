import React, { useState } from 'react';
import './LeadFormModal.css';

function LeadFormModal({ property, onClose, onSubmit }) {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    message: `I'm interested in ${property?.title || 'this property'}...`
  });
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleInputChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsSubmitting(true);
    
    // Simulate form submission
    setTimeout(() => {
      onSubmit(formData);
      setIsSubmitting(false);
    }, 1000);
  };

  if (!property) return null;

  return (
    <div className="lead-modal-overlay" onClick={onClose}>
      <div className="lead-modal-content" onClick={(e) => e.stopPropagation()}>
        <button className="lead-modal-close" onClick={onClose}>×</button>
        
        <div className="lead-modal-body">
          {/* Left Side */}
          <div className="lead-modal-left">
            <div className="lead-modal-icon">
              <img 
                src="https://cdn-icons-png.flaticon.com/512/263/263115.png" 
                alt="Property"
              />
            </div>
            <h3>Interested in this property?</h3>
            <p>Fill out the form and our property expert will get back to you shortly.</p>
            
            <div className="lead-benefits">
              <div className="benefit-item">
                <span className="benefit-icon">✓</span>
                <span>Personalized Assistance</span>
              </div>
              <div className="benefit-item">
                <span className="benefit-icon">✓</span>
                <span>Best Price Guarantee</span>
              </div>
              <div className="benefit-item">
                <span className="benefit-icon">✓</span>
                <span>Expert Property Guidance</span>
              </div>
              <div className="benefit-item">
                <span className="benefit-icon">✓</span>
                <span>100% Secure & Confidential</span>
              </div>
            </div>
          </div>

          {/* Right Side - Form */}
          <div className="lead-modal-right">
            <div className="lead-form-header">
              <h3>Get More Details</h3>
              <p>Please fill in your details and we will contact you soon.</p>
            </div>
            
            <form onSubmit={handleSubmit} className="lead-form">
              <div className="form-group">
                <div className="input-icon-wrapper">
                  <span className="input-icon">👤</span>
                  <input 
                    type="text" 
                    name="name" 
                    placeholder="Your Name*" 
                    value={formData.name}
                    onChange={handleInputChange}
                    required
                  />
                </div>
              </div>
              
              <div className="form-group">
                <div className="input-icon-wrapper">
                  <span className="input-icon">✉</span>
                  <input 
                    type="email" 
                    name="email" 
                    placeholder="Your Email*" 
                    value={formData.email}
                    onChange={handleInputChange}
                    required
                  />
                </div>
              </div>
              
              <div className="form-group">
                <div className="input-icon-wrapper">
                  <span className="input-icon">📞</span>
                  <input 
                    type="tel" 
                    name="phone" 
                    placeholder="Your Phone Number*" 
                    value={formData.phone}
                    onChange={handleInputChange}
                    required
                  />
                </div>
              </div>
              
              <div className="form-group">
                <div className="input-icon-wrapper">
                  <span className="input-icon">💬</span>
                  <textarea 
                    name="message" 
                    placeholder="I'm interested in..."
                    value={formData.message}
                    onChange={handleInputChange}
                    rows="3"
                  ></textarea>
                </div>
              </div>
              
              <button 
                type="submit" 
                className="btn-submit-lead"
                disabled={isSubmitting}
              >
                {isSubmitting ? 'Submitting...' : 'Submit Enquiry'}
              </button>
              
              <p className="form-privacy-note">
                 Your information is safe with us. We don't share your details with third parties.
              </p>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
}

export default LeadFormModal;
